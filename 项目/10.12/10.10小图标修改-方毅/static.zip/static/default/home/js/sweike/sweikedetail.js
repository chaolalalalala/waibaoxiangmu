//$(function(){
//
//    var red = $(".jindu_out").attr("data");
//    console.log(red)
//    var red_line = $(".jindu_y_q_blue_s").attr("data");
//
//    var grey = $(".jindu_next").attr("data");
//
//    var grey_line = $(".jindu_y_q_gray").attr("data");
//
//
//
//
//    //console.log( grey)
//
//
//
//})