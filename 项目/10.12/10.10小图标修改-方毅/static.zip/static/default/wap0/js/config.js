/**
 * Created by Administrator on 2017/3/9.
 */

//私有配置文件
function privateConfigData(){

    /*
    * homeRollType  定义首页滚动播放的内容
    * 2或者'': 行业资讯 ;      1:官方公告
    *
    * UIStyle   定义UI风格
    * 1:默认aui2风格 id=style_A  2:weui风格 id=style_B
    **/
    return {
        homeRollType:1,
        UIStyle:1
    };
}